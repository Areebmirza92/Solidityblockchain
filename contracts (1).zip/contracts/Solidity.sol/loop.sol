// SPDX-License-Identifier: GPL-3.0

pragma solidity >=0.8.2 <0.9.0;

contract loop{
    //While loop
    //for loop
    //do loop

    function whileloop() public pure returns(uint) {
        uint sum;
        uint count;
        // while (count<5){
        //     sum=sum+count;
        //     count++;
    // for (uint count=0; count<5; count++){
    //     sum=sum+count;
    // }
        do{
             sum=sum+count;
            count++;
        } while(count<5);
        
        return sum;
    }
}