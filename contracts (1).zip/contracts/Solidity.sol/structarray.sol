// SPDX-License-Identifier: GPL-3.0

pragma solidity >=0.8.2 <0.9.0;

contract demo{
    struct Student{
    string name;
    uint roll;
    bool pass;
    }
    Student[4] public s;

    function insertStudent(uint index,string memory _name,uint _roll,bool _pass) public {
      s[index]=Student(_name,_roll,_pass);


    }
    function returnStudent(uint index) public view returns(Student memory){
        return s[index];
    }
}