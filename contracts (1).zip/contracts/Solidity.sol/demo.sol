// SPDX-License-Identifier: GPL-3.0

pragma solidity >=0.8.2 <0.9.0;

 contract demo{
   uint public num=5;
 
//   constructor(){
//    //   /* num = 10; */
    
//  }
       function setter() public{
         num=100;
       }
 }