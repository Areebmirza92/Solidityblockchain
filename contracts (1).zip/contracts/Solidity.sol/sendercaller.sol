// SPDX-License-Identifier: GPL-3.0

pragma solidity >=0.8.2 <0.9.0;

contract Demo {
   // function CallerAddress() public view returns (address){
    //    return msg.sender;

    //Transfer ether to my contract
    function sendEtherToContract() public payable{

    }
    function balanceofContract() public view returns(uint){
        return address(this).balance;
    }

}












